package main;

import view.StartView;

public class Main {
    public static void main(String[] args) {
        new StartView();  // Inicia pela tela inicial
    }
}
