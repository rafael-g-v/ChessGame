package main;

import view.ConsoleView;

public class Main {
    public static void main(String[] args) 
    {
        new ConsoleView();
    }
}
