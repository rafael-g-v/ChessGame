package controller;

import model.ChessModel;

public class GameController {
	/*
    private ChessModel model;

    public GameController() {
        model = ChessModel.getInstance();
    }

    public boolean selecionarPeca(int row, int col) {
        return model.selectTargetSquare(row, col);
    }

    public boolean selecionarDestino(int row, int col) {
        return model.selectTargetSquare(row, col);
    }

    public boolean isTurnoBranco() {
        return model.isWhiteTurn();
    }

	 */
}
