package view;

public class ConsoleView implements GameView {
    /*@Override
    public void displayBoard(Board board) {
        // imprime o tabuleiro no console
    }

    @Override
    public Position askForMove() {
        // lê entrada do jogador
        return new Position(0, 0); // exemplo
    }

    @Override
    public void showMessage(String message) {
        System.out.println(message);
    }*/
}
